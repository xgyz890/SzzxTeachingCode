#方法一

dict1={0:[100,90,80,98],1:[38,69,9,45],2:[83,58,75,91],3:[70,28,87,10]}
while True:
    x=int(input())
    for key in dict1:
        for i in range(len(dict1[key])):
            if dict1[key][i]==x:
                print(key+i)
                pos_i=key
                pos_j=i
                
    hang=0
    for a in range(4):
        hang=hang+dict1[pos_i][a]
    print(hang)
    lie=0
    for b in range(4):
        lie=lie+dict1[b][pos_j]
    print(lie)


#方法二            
list1=[[100,90,80,98],[38,69,9,45],[83,58,75,91],[70,28,87,10]]
while True:
    x=int(input())
    for i in range(len(list1)):
        for j in range(len(list1[i])):
            if list1[i][j]==x:
                print(i+j)
                pos_i=i
                pos_j=j
                
    hang=0
    for a in range(4):
        hang=hang+list1[pos_i][a]
    print(hang)
    lie=0
    for b in range(4):
        lie=lie+list1[b][pos_j]
    print(lie)
