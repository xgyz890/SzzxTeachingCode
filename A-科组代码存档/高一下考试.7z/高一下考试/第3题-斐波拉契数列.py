#斐波那契数列（Fibonacci sequence），又称黄金分割数列、因数学家列昂纳多·斐波那契（Leonardoda Fibonacci）以兔子繁殖为例子而引入，故又称为“兔子数列”，指的是这样一个数列：1、1、2、3、5、8、13、21、34、……
#这个数列的第1项为1，第二项也为1，从第3项开始，每一项都等于前两项之和。
#要求建立斐波拉契数列的列表，输入正整数n(n>=3)，输出斐波拉契数列中前n项数之和。
#例如，输入：5，前三项之和=1+1+2+3+5=12，输出结果：12

'''
#方法一，用append函数为列表添加新元素， 列表名.append(元素值)，
#例如：list1.append(1),其作用为在列表list1的最后位置新增一个值为1的元素

while True:
    n=int(input())
    fib=[]
    fib.append(1)
    fib.append(1)
    s=2

    for i in range(2,n):
        fib.append(fib[i-1]+fib[i-2])
        s=s+fib[i]
    print(s)
    #print (fib)
'''
#方法二，创建长度为n的空列表，
#例如，创建一个长度为n的空列表：list1=[]*n    
while True:
    n=int(input())
    fib=[1]*n
    s=2

    for i in range(2,n):
        fib[i]=fib[i-1]+fib[i-2]
        s=s+fib[i]
    print(s)
    print(fib)
        
