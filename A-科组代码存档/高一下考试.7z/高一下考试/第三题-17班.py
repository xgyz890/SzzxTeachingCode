#


while True:
    n=int(input())
    list1=[]
    s=0
    i=1
    while n>=i:
            for j in range(i):
                list1.append(i)
            n=n-i
            i+=1
            
    print(list1)
    
    for j in range(n):
        list1.append(i)
                
    print(list1)
    for i in range(len(list1)):
        s=s+list1[i]
    print(s)
    
            
